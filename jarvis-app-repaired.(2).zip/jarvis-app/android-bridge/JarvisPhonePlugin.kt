package com.you.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.provider.Telephony
import android.telephony.SmsManager
import androidx.core.app.ActivityCompat
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin

@CapacitorPlugin(name = "JarvisPhone")
class JarvisPhonePlugin : Plugin() {
    @PluginMethod
    fun requestPermissions(call: PluginCall) {
        val permissions = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS)
        val missing = permissions.filter { ActivityCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(activity, missing.toTypedArray(), 9101)
        val requested = JSArray(); permissions.forEach { requested.put(it) }
        val result = JSObject(); result.put("requested", requested); result.put("note", "Android may restrict SMS and background microphone access; show an explanation before this call."); call.resolve(result)
    }

    @PluginMethod
    fun call(call: PluginCall) {
        val number = call.getString("number") ?: return call.reject("number is required")
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return call.reject("CALL_PHONE permission is required")
        startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}"))); call.resolve()
    }

    @PluginMethod
    fun sendSms(call: PluginCall) {
        val number = call.getString("number") ?: return call.reject("number is required")
        val body = call.getString("body") ?: return call.reject("body is required")
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return call.reject("SEND_SMS permission is required")
        SmsManager.getDefault().sendTextMessage(number, null, body, null, null); call.resolve()
    }

    @PluginMethod
    fun readSms(call: PluginCall) {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) return call.reject("READ_SMS permission is required")
        val messages = JSArray()
        val projection = arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE)
        context.contentResolver.query(Telephony.Sms.CONTENT_URI, projection, null, null, "${Telephony.Sms.DATE} DESC")?.use { cursor ->
            val addressIndex = cursor.getColumnIndex(Telephony.Sms.ADDRESS)
            val bodyIndex = cursor.getColumnIndex(Telephony.Sms.BODY)
            val dateIndex = cursor.getColumnIndex(Telephony.Sms.DATE)
            var count = 0
            while (cursor.moveToNext() && count++ < 50) {
                val item = JSObject()
                item.put("address", if (addressIndex >= 0) cursor.getString(addressIndex) else "")
                item.put("body", if (bodyIndex >= 0) cursor.getString(bodyIndex) else "")
                item.put("date", if (dateIndex >= 0) cursor.getLong(dateIndex) else 0L)
                messages.put(item)
            }
        }
        val result = JSObject(); result.put("messages", messages); call.resolve(result)
    }

    @PluginMethod
    fun openApp(call: PluginCall) {
        val packageName = call.getString("packageName") ?: return call.reject("packageName is required")
        val launch = context.packageManager.getLaunchIntentForPackage(packageName) ?: return call.reject("App not found")
        startActivity(launch); call.resolve()
    }

    @PluginMethod
    fun openAccessibilitySettings(call: PluginCall) {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); call.resolve()
    }
}
