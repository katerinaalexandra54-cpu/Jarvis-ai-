# JarvisPhone Android bridge

The web app can recognize speech while its page is open using the browser Web Speech API. It cannot keep a microphone or wake-word listener alive after the app is closed; Android requires a native foreground service and visible notification for that behavior.

## Native pieces still required in the Capacitor Android project

1. Register `JarvisPhonePlugin` with the Capacitor bridge.
2. Add runtime permissions for `RECORD_AUDIO`, `POST_NOTIFICATIONS`, `CALL_PHONE`, and the SMS permissions only when the product policy and distribution channel allow them.
3. Add a foreground `JarvisVoiceService` for an explicitly enabled wake-word mode. The service must show a persistent notification, stop cleanly, and never record without user consent.
4. Add a `NotificationListenerService` only after explaining its scope to the user. Use Android accessibility APIs only for supported, user-authorized actions—not arbitrary control.
5. Require confirmation before sending a message, placing a call, or executing a consequential device action.

The included Kotlin file implements the basic permission-gated bridge methods for calls, SMS sending, opening apps, and opening accessibility settings. It is a foundation, not a claim that background listening is already active.
