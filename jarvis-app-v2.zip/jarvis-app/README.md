# JARVIS (Android)

Voice assistant app: talk to Jarvis, it answers out loud and controls your phone (alarms, timers, open apps,
screenshots, Home/Back/Recents, flashlight, calls, read and send texts) after you grant permissions.
Chat, summarizer, image generator, translator, calculator and document analysis run on OpenRouter.

## Run in a browser (design + chat testing)
    npm install
    npm run dev

Phone actions only work inside the Android app. Voice input in a browser needs Chrome.

## Build the APK on GitHub
Push this folder to a repo. `.github/workflows/build-apk.yml` runs on every push to `main`:
it builds the web app, creates the Android project, installs the Jarvis phone plugin, icons and permissions
(`scripts/setup-android.mjs`) and uploads `jarvis-debug-apk` under Actions > the run > Artifacts.

## Build locally
    npm install
    npm run build
    npx cap add android
    npm run android:setup
    npx cap sync android
    cd android && ./gradlew assembleDebug

## First run on the phone
1. Create an account (stored on the phone).
2. Ask Jarvis anything. It asks for your OpenRouter key once (or paste it in Settings > AI Preferences).
3. Settings > Phone Control: tap Allow permissions, then Turn on Accessibility and enable Jarvis
   (needed for screenshots, Home, Back, Recents).

## Logo
`public/assets/jarvis-mark.jpg` is the in-app logo. Launcher icons and splash are generated into
`android-bridge/res` and copied by the setup script. Replace the jpg with a higher-resolution file and re-run
the icon step to sharpen them.

`server/` is the old Anthropic proxy and is no longer used by the app.
