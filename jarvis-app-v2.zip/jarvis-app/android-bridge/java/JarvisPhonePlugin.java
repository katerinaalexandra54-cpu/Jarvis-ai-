package com.you.jarvis;

import android.Manifest;
import android.accessibilityservice.AccessibilityService;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.provider.Telephony;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.telephony.SmsManager;
import android.util.Base64;

import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@CapacitorPlugin(
    name = "JarvisPhone",
    permissions = {
        @Permission(alias = "mic", strings = { Manifest.permission.RECORD_AUDIO }),
        @Permission(alias = "contacts", strings = { Manifest.permission.READ_CONTACTS }),
        @Permission(alias = "phone", strings = { Manifest.permission.CALL_PHONE }),
        @Permission(alias = "sms", strings = { Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS })
    }
)
public class JarvisPhonePlugin extends Plugin {

    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String queuedSpeech = null;

    private boolean has(String permission) {
        return ContextCompat.checkSelfPermission(getContext(), permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void launch(Intent intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(intent);
    }

    // ---------- permissions & status ----------

    private JSObject statusObject() {
        JSObject o = new JSObject();
        o.put("mic", has(Manifest.permission.RECORD_AUDIO));
        o.put("contacts", has(Manifest.permission.READ_CONTACTS));
        o.put("phone", has(Manifest.permission.CALL_PHONE));
        o.put("sms", has(Manifest.permission.SEND_SMS) && has(Manifest.permission.READ_SMS));
        o.put("accessibility", JarvisAccessibilityService.instance != null);
        return o;
    }

    @PluginMethod
    public void status(PluginCall call) {
        call.resolve(statusObject());
    }

    @PluginMethod
    public void requestAllPermissions(PluginCall call) {
        requestPermissionForAliases(new String[] { "mic", "contacts", "phone", "sms" }, call, "permissionsDone");
    }

    @PermissionCallback
    private void permissionsDone(PluginCall call) {
        call.resolve(statusObject());
    }

    @PluginMethod
    public void openAccessibilitySettings(PluginCall call) {
        launch(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        call.resolve();
    }

    // ---------- voice ----------

    @PluginMethod
    public void listen(final PluginCall call) {
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            call.reject("Microphone permission is needed. Allow it in Settings > Phone Control.");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(getContext())) {
            call.reject("Speech recognition is not available on this phone.");
            return;
        }
        final String lang = call.getString("lang", Locale.getDefault().toLanguageTag());
        getActivity().runOnUiThread(() -> {
            try {
                if (recognizer != null) recognizer.destroy();
                recognizer = SpeechRecognizer.createSpeechRecognizer(getContext());
                recognizer.setRecognitionListener(new RecognitionListener() {
                    @Override public void onReadyForSpeech(Bundle params) { }
                    @Override public void onBeginningOfSpeech() { }
                    @Override public void onRmsChanged(float rmsdB) { }
                    @Override public void onBufferReceived(byte[] buffer) { }
                    @Override public void onEndOfSpeech() { }
                    @Override public void onEvent(int eventType, Bundle params) { }

                    @Override
                    public void onError(int error) {
                        call.reject("I didn't catch that (code " + error + ").");
                    }

                    @Override
                    public void onResults(Bundle results) {
                        ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        JSObject o = new JSObject();
                        o.put("text", (list != null && !list.isEmpty()) ? list.get(0) : "");
                        call.resolve(o);
                    }

                    @Override
                    public void onPartialResults(Bundle partial) {
                        ArrayList<String> list = partial.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (list != null && !list.isEmpty()) {
                            JSObject o = new JSObject();
                            o.put("text", list.get(0));
                            notifyListeners("partial", o);
                        }
                    }
                });
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
                recognizer.startListening(i);
            } catch (Exception e) {
                call.reject(String.valueOf(e.getMessage()));
            }
        });
    }

    @PluginMethod
    public void stopListening(final PluginCall call) {
        getActivity().runOnUiThread(() -> {
            if (recognizer != null) recognizer.stopListening();
            call.resolve();
        });
    }

    @PluginMethod
    public void speak(PluginCall call) {
        final String text = call.getString("text", "");
        if (tts == null) {
            queuedSpeech = text;
            tts = new TextToSpeech(getContext(), status -> {
                ttsReady = (status == TextToSpeech.SUCCESS);
                if (ttsReady) {
                    tts.setLanguage(Locale.getDefault());
                    if (queuedSpeech != null) {
                        tts.speak(queuedSpeech, TextToSpeech.QUEUE_FLUSH, null, "jarvis");
                        queuedSpeech = null;
                    }
                }
            });
        } else if (ttsReady) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis");
        } else {
            queuedSpeech = text;
        }
        call.resolve();
    }

    @PluginMethod
    public void stopSpeaking(PluginCall call) {
        if (tts != null && ttsReady) tts.stop();
        call.resolve();
    }

    // ---------- alarms, timers, apps, settings ----------

    @PluginMethod
    public void setAlarm(PluginCall call) {
        Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
        int hour = call.getInt("hour", 7);
        int minute = call.getInt("minute", 0);
        i.putExtra(AlarmClock.EXTRA_HOUR, hour);
        i.putExtra(AlarmClock.EXTRA_MINUTES, minute);
        i.putExtra(AlarmClock.EXTRA_MESSAGE, call.getString("label", "Jarvis alarm"));
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        try {
            launch(i);
            call.resolve();
        } catch (ActivityNotFoundException e) {
            call.reject("No clock app found to set the alarm.");
        }
    }

    @PluginMethod
    public void setTimer(PluginCall call) {
        Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
        int seconds = call.getInt("seconds", 60);
        i.putExtra(AlarmClock.EXTRA_LENGTH, seconds);
        i.putExtra(AlarmClock.EXTRA_MESSAGE, call.getString("label", "Jarvis timer"));
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        try {
            launch(i);
            call.resolve();
        } catch (ActivityNotFoundException e) {
            call.reject("No clock app found to start the timer.");
        }
    }

    @PluginMethod
    public void openApp(PluginCall call) {
        String name = call.getString("name", "").trim().toLowerCase(Locale.ROOT);
        if (name.isEmpty()) { call.reject("Which app should I open?"); return; }
        PackageManager pm = getContext().getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
        ResolveInfo best = null;
        for (ResolveInfo ri : apps) {
            String label = ri.loadLabel(pm).toString().toLowerCase(Locale.ROOT);
            if (label.equals(name)) { best = ri; break; }
            if (best == null && (label.contains(name) || name.contains(label))) best = ri;
        }
        if (best == null) { call.reject("I couldn't find an app called " + name + "."); return; }
        Intent launch = pm.getLaunchIntentForPackage(best.activityInfo.packageName);
        if (launch == null) { call.reject("I can't open that app."); return; }
        launch(launch);
        JSObject o = new JSObject();
        o.put("app", best.loadLabel(pm).toString());
        call.resolve(o);
    }

    @PluginMethod
    public void openSettings(PluginCall call) {
        String page = call.getString("page", "");
        String action;
        switch (page) {
            case "wifi": action = Settings.ACTION_WIFI_SETTINGS; break;
            case "bluetooth": action = Settings.ACTION_BLUETOOTH_SETTINGS; break;
            case "display": action = Settings.ACTION_DISPLAY_SETTINGS; break;
            case "sound": action = Settings.ACTION_SOUND_SETTINGS; break;
            case "battery": action = Settings.ACTION_BATTERY_SAVER_SETTINGS; break;
            case "location": action = Settings.ACTION_LOCATION_SOURCE_SETTINGS; break;
            case "apps": action = Settings.ACTION_APPLICATION_SETTINGS; break;
            case "accessibility": action = Settings.ACTION_ACCESSIBILITY_SETTINGS; break;
            default: action = Settings.ACTION_SETTINGS;
        }
        try { launch(new Intent(action)); call.resolve(); }
        catch (ActivityNotFoundException e) { call.reject("That settings page isn't available."); }
    }

    @PluginMethod
    public void openUrl(PluginCall call) {
        try { launch(new Intent(Intent.ACTION_VIEW, Uri.parse(call.getString("url", "")))); call.resolve(); }
        catch (Exception e) { call.reject("I couldn't open that link."); }
    }

    @PluginMethod
    public void flashlight(PluginCall call) {
        try {
            CameraManager cm = (CameraManager) getContext().getSystemService(Context.CAMERA_SERVICE);
            cm.setTorchMode(cm.getCameraIdList()[0], call.getBoolean("on", true));
            call.resolve();
        } catch (Exception e) {
            call.reject("I couldn't switch the flashlight.");
        }
    }

    @PluginMethod
    public void globalAction(PluginCall call) {
        JarvisAccessibilityService svc = JarvisAccessibilityService.instance;
        if (svc == null) {
            call.reject("Turn on Jarvis in Accessibility settings first (Settings > Phone Control).");
            return;
        }
        String a = call.getString("action", "");
        int code;
        switch (a) {
            case "home": code = AccessibilityService.GLOBAL_ACTION_HOME; break;
            case "back": code = AccessibilityService.GLOBAL_ACTION_BACK; break;
            case "recents": code = AccessibilityService.GLOBAL_ACTION_RECENTS; break;
            case "notifications": code = AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS; break;
            case "quickSettings": code = AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS; break;
            case "powerDialog": code = AccessibilityService.GLOBAL_ACTION_POWER_DIALOG; break;
            case "screenshot":
                if (Build.VERSION.SDK_INT < 28) { call.reject("Screenshots need Android 9 or newer."); return; }
                code = AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT; break;
            case "lock":
                if (Build.VERSION.SDK_INT < 28) { call.reject("Locking needs Android 9 or newer."); return; }
                code = AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN; break;
            default: call.reject("Unknown action."); return;
        }
        if (svc.performGlobalAction(code)) call.resolve(); else call.reject("Android refused that action.");
    }

    // ---------- contacts, calls, texts ----------

    private String nameFor(String number) {
        if (number == null || !has(Manifest.permission.READ_CONTACTS)) return number;
        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number));
        try (Cursor c = getContext().getContentResolver().query(uri,
                new String[] { ContactsContract.PhoneLookup.DISPLAY_NAME }, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) { }
        return number;
    }

    private JSObject lookup(String name) throws Exception {
        if (!has(Manifest.permission.READ_CONTACTS)) throw new Exception("Contacts permission is needed.");
        try (Cursor c = getContext().getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[] { ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER },
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                new String[] { "%" + name + "%" }, null)) {
            if (c != null && c.moveToFirst()) {
                JSObject o = new JSObject();
                o.put("name", c.getString(0));
                o.put("number", c.getString(1));
                return o;
            }
        }
        throw new Exception("I couldn't find " + name + " in your contacts.");
    }

    @PluginMethod
    public void findContact(PluginCall call) {
        try { call.resolve(lookup(call.getString("name", ""))); }
        catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void placeCall(PluginCall call) {
        if (!has(Manifest.permission.CALL_PHONE)) { call.reject("Phone permission is needed."); return; }
        String number = call.getString("number", "");
        try {
            launch(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))));
            call.resolve();
        } catch (Exception e) { call.reject("I couldn't place the call."); }
    }

    @PluginMethod
    public void sendSms(PluginCall call) {
        if (!has(Manifest.permission.SEND_SMS)) { call.reject("SMS permission is needed."); return; }
        String number = call.getString("number", "");
        String body = call.getString("body", "");
        try {
            SmsManager sm = Build.VERSION.SDK_INT >= 31
                ? getContext().getSystemService(SmsManager.class)
                : SmsManager.getDefault();
            sm.sendMultipartTextMessage(number, null, sm.divideMessage(body), null, null);
            call.resolve();
        } catch (Exception e) { call.reject("The message didn't send: " + e.getMessage()); }
    }

    @PluginMethod
    public void readSms(PluginCall call) {
        if (!has(Manifest.permission.READ_SMS)) { call.reject("SMS permission is needed."); return; }
        int count = call.getInt("count", 3);
        String from = call.getString("from", "").toLowerCase(Locale.ROOT);
        JSArray out = new JSArray();
        try (Cursor c = getContext().getContentResolver().query(Telephony.Sms.Inbox.CONTENT_URI,
                new String[] { Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE },
                null, null, Telephony.Sms.DATE + " DESC LIMIT 60")) {
            while (c != null && c.moveToNext() && out.length() < count) {
                String address = c.getString(0);
                String name = nameFor(address);
                if (!from.isEmpty()
                        && !String.valueOf(name).toLowerCase(Locale.ROOT).contains(from)
                        && !String.valueOf(address).toLowerCase(Locale.ROOT).contains(from)) continue;
                JSObject m = new JSObject();
                m.put("address", address);
                m.put("name", name);
                m.put("body", c.getString(1));
                m.put("date", c.getLong(2));
                out.put(m);
            }
        } catch (Exception e) { call.reject("I couldn't read your messages."); return; }
        JSObject o = new JSObject();
        o.put("messages", out);
        call.resolve(o);
    }

    // ---------- images ----------

    @PluginMethod
    public void saveImage(PluginCall call) {
        if (Build.VERSION.SDK_INT < 29) { call.reject("Saving images needs Android 10 or newer."); return; }
        String data = call.getString("dataUrl", "");
        String mime = call.getString("mime", "image/png");
        String name = call.getString("name", "jarvis-image");
        try {
            byte[] bytes = Base64.decode(data.substring(data.indexOf(",") + 1), Base64.DEFAULT);
            ContentResolver r = getContext().getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Images.Media.MIME_TYPE, mime);
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Jarvis");
            Uri uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            try (OutputStream os = r.openOutputStream(uri)) { os.write(bytes); }
            call.resolve();
        } catch (Exception e) { call.reject("Couldn't save the image."); }
    }
}
