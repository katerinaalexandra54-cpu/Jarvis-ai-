# Jarvis
React + Vite + three.js front end, Node/Express server (keeps API keys private).
## Run
    npm install && cp .env.example .env   # add server keys locally; never put them in VITE_* variables
    npm run dev     # app on :5173, server on :8787
    npm start       # production build served on :8787
## APK (Capacitor)
    npm i @capacitor/core @capacitor/cli @capacitor/android && npx cap init Jarvis com.you.jarvis --web-dir dist
    VITE_API=https://your-server.example npm run build && npx cap add android && npx cap sync && npx cap open android

For a local browser build, leave `VITE_API` empty so Vite proxies `/api` to port 8787. For an APK, set `VITE_API` to the public HTTPS URL of the deployed Node server; the APK cannot use the browser-only Vite proxy.
## Phone control
`src/phone.js` calls a native Capacitor plugin named `JarvisPhone` (readSms, sendSms, call, openApp, requestPermissions) that still has to be written in Kotlin/Java: SMS/phone permissions, a NotificationListenerService, and an AccessibilityService for broader control. Google Play restricts SMS access, so sideload the APK.
