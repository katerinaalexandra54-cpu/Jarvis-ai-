import { useCallback, useEffect, useRef, useState } from 'react';
import { complete, parseJSON, assistantPrompt, NoKeyError } from './lib/ai.js';
import { listen, runAction, resolveTarget, speak, stopSpeaking, stopListening } from './lib/phone.js';
import { load, save, uid } from './lib/store.js';

const YES = /^(yes|yeah|yep|yup|sure|ok|okay|send( it)?|do it|confirm|go ahead|call( them)?|please do)\b/i;
const NO = /^(no|nope|cancel|stop|don'?t|never mind|nevermind)\b/i;

const hello = name => ({ id: 'hello', from: 'jarvis', ts: Date.now(), text: `Hello ${name || 'there'}! I'm JARVIS. How can I help you today?` });

export function useAssistant({ settings, user, askKey, upsertHistory, notify }) {
  const [messages, setMessages] = useState(() => { const m = load('chat', []); return m.length ? m : [hello(user?.name)]; });
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const [partial, setPartial] = useState('');
  const [pending, setPendingState] = useState(null);
  const pendingRef = useRef(null);
  const lastSms = useRef(load('lastSms', ''));
  const chatId = useRef(load('chatId', null) || uid());
  const busyRef = useRef(false);

  const setPending = p => { pendingRef.current = p; setPendingState(p); };
  useEffect(() => { save('chat', messages.slice(-60)); save('chatId', chatId.current); }, [messages]);

  const push = useCallback(m => setMessages(ms => [...ms, { id: uid(), ts: Date.now(), ...m }]), []);
  const reply = useCallback((text, speakIt) => { push({ from: 'jarvis', text }); if (speakIt) speak(text); }, [push]);

  const execute = useCallback(async (action, speakIt) => {
    try {
      const r = await runAction(action);
      if (r.sms) {
        if (!r.sms.length) return reply('You have no matching messages.', speakIt);
        lastSms.current = r.sms[0].name || r.sms[0].address; save('lastSms', lastSms.current);
        const text = r.sms.map(m => `${m.name || m.address}: ${m.body}`).join('\n');
        push({ from: 'jarvis', text }); if (speakIt) speak(r.sms.map(m => `Message from ${m.name || m.address}. ${m.body}`).join(' '));
      } else if (r.note) push({ from: 'jarvis', text: r.note, small: true });
    } catch (e) { reply(e.message, speakIt); }
  }, [push, reply]);

  const send = useCallback(async (raw, { viaVoice = false } = {}) => {
    const text = raw.trim();
    if (!text || busyRef.current) return;
    const speakIt = viaVoice || settings.speakReplies;
    stopSpeaking();
    push({ from: 'user', text });
    upsertHistory({ id: chatId.current, type: 'chat', icon: 'chat', title: text.slice(0, 48), payload: { screen: 'chat' } });

    const p = pendingRef.current;
    if (p) {
      if (YES.test(text)) { setPending(null); reply(p.action.type === 'call' ? `Calling ${p.label}.` : 'Sending it now.', speakIt); return execute(p.action, speakIt); }
      if (NO.test(text)) { setPending(null); return reply('Okay, cancelled.', speakIt); }
      setPending(null);
    }

    busyRef.current = true; setBusy(true);
    try {
      const history = messages.filter(m => m.id !== 'hello' && !m.small).slice(-10)
        .map(m => m.from === 'user' ? { role: 'user', content: m.text } : { role: 'assistant', content: JSON.stringify({ say: m.text, action: null }) });
      const out = await complete(settings, [
        { role: 'system', content: assistantPrompt({ now: new Date().toString(), lastSms: lastSms.current, name: user?.name }) },
        ...history, { role: 'user', content: text },
      ]);
      const parsed = parseJSON(out);
      const say = (parsed?.say || (parsed ? '' : out) || 'Done.').trim();
      const action = parsed?.action && parsed.action.type ? parsed.action : null;
      if (!action) return reply(say, speakIt);

      if (action.type === 'call' || action.type === 'sendSms') {
        let target;
        try { target = await resolveTarget(action.to || ''); } catch (e) { return reply(e.message, speakIt); }
        const resolved = { ...action, number: target.number };
        const label = target.name;
        setPending({ action: resolved, label });
        const ask = action.type === 'call' ? `Call ${label}?` : `Send to ${label}: "${action.body}". Should I send it?`;
        push({ from: 'jarvis', text: ask, confirm: true });
        if (speakIt) speak(ask);
        if (viaVoice) { setTimeout(() => { if (pendingRef.current) voiceRef.current?.(); }, 2800); }
        return;
      }
      reply(say, speakIt);
      await execute(action, speakIt);
    } catch (e) {
      if (e instanceof NoKeyError) { askKey(); reply('I need your OpenRouter key before I can think. Paste it in the box that just opened.', false); }
      else reply(e.message, false);
    } finally { busyRef.current = false; setBusy(false); }
  }, [messages, settings, user, push, reply, execute, askKey, upsertHistory]);

  const voiceRef = useRef(null);
  const startVoice = useCallback(async () => {
    if (listening) { stopListening(); return; }
    stopSpeaking(); setListening(true); setPartial('');
    try {
      const heard = await listen(setPartial, settings.lang);
      setListening(false); setPartial('');
      if (heard.trim()) await send(heard, { viaVoice: true });
    } catch (e) { setListening(false); setPartial(''); notify(e.message); }
  }, [listening, settings.lang, send, notify]);
  voiceRef.current = startVoice;

  const confirm = ok => send(ok ? 'yes' : 'no');
  const reset = () => { chatId.current = uid(); setPending(null); setMessages([hello(user?.name)]); };

  return { messages, busy, listening, partial, pending, send, startVoice, confirm, reset };
}
