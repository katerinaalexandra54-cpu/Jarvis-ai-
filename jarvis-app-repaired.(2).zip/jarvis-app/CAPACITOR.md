# Android / Capacitor handoff

The web app is ready to package with Capacitor:

```bash
npm i @capacitor/core @capacitor/cli @capacitor/android
npx cap init Jarvis com.you.jarvis --web-dir dist
npm run build
npx cap add android
npx cap sync
npx cap open android
```

## Native bridge contract

The UI and server intentionally do not claim phone access by themselves. A Kotlin Capacitor plugin named `JarvisPhone` should implement these methods after Android runtime permissions are granted:

- `requestPermissions`
- `readSms`
- `sendSms`
- `call`
- `openApp`

Add a visible permission explanation in the Android app before requesting permissions. SMS and accessibility capabilities are sensitive Android permissions and may have Play policy restrictions; use a compliant distribution path and keep user confirmation around sending messages or initiating calls.
